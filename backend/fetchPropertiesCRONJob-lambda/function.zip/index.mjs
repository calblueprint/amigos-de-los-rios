import { createClient } from "@supabase/supabase-js";

// ── Environment variables ──────────────────────────────────────────────────────
const PLANITGEO_API_KEY = process.env.PLANITGEO_API_KEY;
const PLANITGEO_USERNAME = process.env.PLANITGEO_USERNAME;
const PLANITGEO_PASSWORD = process.env.PLANITGEO_PASSWORD;
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (
  !PLANITGEO_API_KEY ||
  !PLANITGEO_USERNAME ||
  !PLANITGEO_PASSWORD ||
  !SUPABASE_URL ||
  !SUPABASE_SERVICE_ROLE_KEY
) {
  throw new Error("Missing required environment variables.");
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

const credentials = Buffer.from(
  `${PLANITGEO_USERNAME}:${PLANITGEO_PASSWORD}`
).toString("base64");

function getAuthHeaders() {
  return {
    Authorization: `Basic ${credentials}`,
    Accept: "application/json",
  };
}

// ── Memory logger ─────────────────────────────────────────────────────────────
function logMemory(label) {
  const mb = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1);
  console.log(`[memory] ${label}: ${mb} MB used`);
}

// ── Transform helpers ─────────────────────────────────────────────────────────
function toDbProperty(f) {
  const p = f.properties;
  const address =
    p.address_number && p.address_street
      ? `${p.address_number} ${p.address_street}`
      : (p.address_num_street ?? "N/A");

  return {
    pid: p.pid,
    address,
    latitude: p.lat,
    longitude: p.lng,
    water_onsite: p._useradd_6865956bca734 === 2,
    num_trees: p.tree_comments ?? "None",
    prev_watered: p.last_modified
      ? new Date(p.last_modified).toISOString()
      : null,
  };
}

function toDbHydrant(f) {
  const p = f.properties;
  const hydrant_address =
    p.address_number && p.address_street
      ? `${p.address_number} ${p.address_street}`
      : (p.address_num_street ?? "N/A");

  return {
    hydrant_id: p.pid,
    hydrant_address,
    latitude: p.lat,
    longitude: p.lng,
    hydrant_type: p.species_common ?? null,
  };
}

// ── Supabase upserts ──────────────────────────────────────────────────────────
async function upsertProperties(properties) {
  if (properties.length === 0) return;
  const { error } = await supabase
    .from("Property")
    .upsert(properties, { onConflict: "pid" });
  if (error) throw new Error(`Properties upsert failed: ${error.message}`);
  console.log(`Upserted ${properties.length} properties.`);
}

async function upsertHydrants(hydrants) {
  if (hydrants.length === 0) return;
  const { error } = await supabase
    .from("Hydrants")
    .upsert(hydrants, { onConflict: "hydrant_id" });
  if (error) throw new Error(`Hydrants upsert failed: ${error.message}`);
  console.log(`Upserted ${hydrants.length} hydrants.`);
}

// ── Lambda handler ────────────────────────────────────────────────────────────
export const handler = async () => {
  console.log("Lambda invoked: starting sync...");
  logMemory("start");

  const LIMIT = 500;
  let offset = 0;
  let totalProperties = 0;
  let totalHydrants = 0;
  let batchNum = 0;

  while (true) {
    batchNum++;
    console.log(`--- Batch ${batchNum} | offset=${offset} ---`);
    logMemory("before fetch");

    const url = `https://pg-cloud.com/api/amigosdelosrios/inventories/trees?apiKey=${PLANITGEO_API_KEY}&offset=${offset}&limit=${LIMIT}`;

    let batch;
    try {
      const res = await fetch(url, { headers: getAuthHeaders() });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`PlanitGeo API error ${res.status}: ${text.slice(0, 300)}`);
      }
      const json = await res.json();
      batch = json?.data?.features ?? [];
      console.log(`Fetched ${batch.length} features`);
    } catch (err) {
      console.error(`Fetch failed at offset ${offset}:`, err.message);
      throw err;
    }

    logMemory("after fetch");

    const properties = batch
      .filter((f) => f.properties?.organization === 176)
      .map(toDbProperty);

    const hydrants = batch
      .filter((f) => f.properties?.organization === 177)
      .map(toDbHydrant);

    console.log(`Filtered: ${properties.length} properties, ${hydrants.length} hydrants`);

    await upsertProperties(properties);
    await upsertHydrants(hydrants);

    totalProperties += properties.length;
    totalHydrants += hydrants.length;

    logMemory("after upsert");

    const done = batch.length < LIMIT;
    batch = null;

    if (done) break;
    offset += LIMIT;
  }

  console.log(`Sync complete. ${totalProperties} properties, ${totalHydrants} hydrants upserted.`);
  return {
    statusCode: 200,
    body: `Sync complete. ${totalProperties} properties, ${totalHydrants} hydrants upserted.`,
  };
};
